# Enigma-Simulator

So I wanted to upload the application but there was an upload limit on github so I just uploaded the code

To run it you are going to need processing, don't worry its free.
https://processing.org/download/

Then download and open the code in processing, and finally press the play button.
